@echo off
net session >nul 2>&1
if %errorLevel% neq 0 (
    powershell -NoProfile -Command "Start-Process cmd.exe -ArgumentList '/c \"\"%~f0\"\"' -Verb RunAs"
    exit /b
)

echo Stopping Wi-Fi Captive Lab and Mock ACS...
powershell -NoProfile -Command "Get-NetTCPConnection -LocalPort 7443,8443,9443 -ErrorAction SilentlyContinue | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }"
powershell -NoProfile -Command "Get-Process python -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowTitle -like '*mock_acs*' -or $_.MainWindowTitle -like '*captive_wifi_lab*' } | Stop-Process -Force -ErrorAction SilentlyContinue"
powershell -NoProfile -Command "if (Test-Path '%~dp0captive-wifi-lab.pid') { Remove-Item '%~dp0captive-wifi-lab.pid' -Force }"

echo Stopping Hosted Network...
netsh wlan stop hostednetwork >nul 2>&1

echo Restarting Windows Time Service...
powershell -NoProfile -Command "Start-Service w32time -ErrorAction SilentlyContinue"

echo Wi-Fi Lab cleanup complete.
timeout /t 2 >nul
