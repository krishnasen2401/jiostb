# Jio STB Wi-Fi Hotspot Captive Lab (ADB Unlock Kit)

This folder contains the standalone **Wi-Fi Hotspot version** of the Jio STB exploit kit. It is designed specifically for users whose PCs or laptops **do not have an Ethernet port**.

By broadcasting a Wi-Fi Hotspot from your Windows PC, the STB connects wirelessly to your PC. The PC intercepts the STB's TR-069 ACS traffic, spoofs Jio's activation servers, and enables permanent **USB/Network ADB Debugging** over Wi-Fi.

No Ethernet cables, no Docker, no MongoDB, and no GenieACS required.

---

## 📁 Files Included

| File | Role |
| :--- | :--- |
| **`RUN_WIFI_LAB.bat`** | **One-click launcher**. Auto-elevates to Administrator and launches `start-wifi-lab.ps1`. |
| **`start-wifi-lab.ps1`** | Auto-detects the Wi-Fi Hotspot adapter, binds alias IPs (`49.44.112.10`, `142.250.190.46`, `8.8.8.8`), opens Windows Firewall rules, stops conflicting `w32time`, and starts the servers. |
| **`captive_wifi_lab.py`** | Wi-Fi captive responder (Subnet `192.168.137.0/24`): <br>• **DNS** (UDP/TCP 53) spoofs `acs.oss.jio.com` $\to$ `49.44.112.10`<br>• **DHCP** coexists gracefully with Windows Mobile Hotspot ICS<br>• **NTP** (UDP 123) provides 64-bit real-world time sync<br>• **HTTP 204** (TCP 80) satisfies Android captive portal checks (`/generate_204`)<br>• **DoT Blocker** (TCP 853) forces fallback to cleartext DNS |
| **`mock_acs.py`** | Pure-Python CWMP/TR-069 ACS server listening on ports `7443`, `8443`, `9443`. Answers `/network/check` with a forged FTTH token and executes `cwmp:SetParameterValues` (`Device.JioSTB.USB.USBDebugging = true`). |
| **`forged_chain.pem`** | Verified TLS certificate chain for `acs.oss.jio.com` trusted by TeleOS truststore. |
| **`KILL_WIFI_LAB.bat`** | **One-click cleanup**. Terminates all background listener processes and restarts the Windows Time Service (`w32time`). |

---

## 🛠️ Prerequisites

1. **Hardware:**
   * Jio STB (JHS D200 v2 / JHS C200 / franklin).
   * Windows 10/11 PC or laptop with a working Wi-Fi adapter.
   * USB mouse plugged into the STB (or STB remote).
2. **Software on PC:**
   * Python 3.8+ installed and added to system PATH.
   * `pycryptodome` (recommended: `pip install pycryptodome`, though a precomputed FTTH token fallback is included).

---

## 🚀 Step-by-Step Instructions

### Step 1: Turn ON Windows Mobile Hotspot
1. On your Windows PC, open **Settings** $\to$ **Network & internet** $\to$ **Mobile hotspot**.
2. Click **Edit** and configure:
   * **Network name:** `JioSTB-Setup`
   * **Network password:** `password123`
   * **Network band:** `2.4 GHz` *(essential — all Jio STB models support 2.4 GHz)*
3. Toggle **Mobile hotspot** to **ON**.

> [!IMPORTANT]
> **Disconnect external internet from the PC** (e.g. unplug your home router's optical fiber/WAN cable or disconnect mobile data). The PC and STB must be in an **isolated offline network** so the STB cannot reach real Jio cloud servers on the internet.

### Step 2: Start the Wi-Fi Lab
1. Right-click **`RUN_WIFI_LAB.bat`** and select **Run as Administrator** (or double-click and click **Yes** on UAC).
2. Two command prompt windows will open:
   * **Window 1 (`mock_acs.py`):** Listening for TR-069 ACS TLS connections on ports `7443, 8443, 9443`.
   * **Window 2 (`captive_wifi_lab.py`):** Handling DNS spoofing, NTP sync, and HTTP 204.

### Step 3: Connect STB to the Hotspot & Reboot
1. On the TV, go to Wi-Fi settings and connect to **`JioSTB-Setup`** (Password: `password123`).
2. **Cold-reboot the STB:** Unplug the power adapter from the wall/box, wait 5 seconds, and plug it back in.

### Step 4: Watch the Handshake
In the terminal windows, you will see in real time:
1. `[DNS] ... queried: acs.oss.jio.com -> resolved: 49.44.112.10`
2. `[PORTAL] ... >>> GET /generate_204 -> returning HTTP 204`
3. `[NTP] Request answered for 192.168.137.x`
4. In `mock_acs`:
   * `[ACS] TLS ok from 192.168.137.x`
   * `>>> POST /network/check -> returning forged FTTH`
   * `>>> POST /acs ... cwmp:Inform`
   * `<<< SetParameterValues (Device.JioSTB.USB.USBDebugging = true)`

### Step 5: Authorize ADB on Screen
1. On your TV screen, an **"Allow USB Debugging?"** dialog will pop up.
2. Using your USB mouse or remote:
   * Check **"Always allow from this computer"**.
   * Click **OK**.

### Step 6: Connect via ADB
Note the client IP logged in the terminal (typically `192.168.137.19` or check via `arp -a -N 192.168.137.1`).
From Command Prompt or PowerShell:
```cmd
adb connect 192.168.137.19:5555
adb devices
```
You now have permanent ADB root/shell access over Wi-Fi.

### Step 7: Clean Up When Done
Double-click **`KILL_WIFI_LAB.bat`** to stop all background lab processes, free ports, and restart the Windows Time Service.
